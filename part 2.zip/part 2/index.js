const services = require('./serviceapp')
const clients = require('./clientapp')

module.exports=(app)=>{
    services(app)
    clients(app)
}