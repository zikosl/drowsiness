
var admin = require("firebase-admin");
let db = require('../mysql')
var serviceAccount = require("../commandi-fd130-firebase-adminsdk-ylk6x-6008ac9ee6.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://commandi-fd130.firebaseio.com"
});
exports.sendClientNotif = async (id,body) =>{
    // Get the owners details
    const row = await db.query('SELECT token From users where id = ?',[id])
    console.log(row)
    await admin.messaging().sendMulticast({
        tokens: [row[0].token], // ['token_1', 'token_2', ...]
        data: {
          title: 'Commandi',
          body: body,
          imageUrl: 'https://my-cdn.com/app-logo.png',
        },
      });
}