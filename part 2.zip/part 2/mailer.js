const nodemailer = require('nodemailer');

let transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    secure: true,
    auth: {
        user: 'zikou.slimi@gmail.com',
        pass: 'tfzia1999'
    }
});

exports.mailer = (data)=>{
    // getting dest email by query string
    const {dest,name,rand} = data;
    //return data
    const mailOptions = {
        from: "Donya's", // Something like: Jane Doe <janedoe@gmail.com>
        to: dest,
        subject: 'Email Validation', // email subject
        html: `<p><span style="font-family: 'courier new', courier, monospace;"><strong>Hello </strong>`+name+`,</span></p>
        <p><span style="font-family: 'courier new', courier, monospace;">You are close to ending Register:</span></p>
        <p style="padding-left: 40px;"><span style="font-family: 'arial black', sans-serif; font-size: 18pt;"><strong>`+rand+`</strong></span></p>
        <p><span style="font-family: 'courier new', courier, monospace;">Best wishes,</span></p>
        <hr style="margin-top: 10px; margin-bottom: 10px;" />
        <p><br /><span style="color: #f1c40f; font-family: impact, sans-serif;">Donya's team</span></p>` // email content in HTML
    };
    transporter.sendMail(mailOptions)
}
