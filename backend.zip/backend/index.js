const express = require('express');
const app = express();
const services = require('./routes/index');
const http = require('http');
const server = http.createServer(app);
const fileUpload = require('express-fileupload');
const { Server } = require("socket.io");
const io = new Server(server);

app.use(fileUpload({
  limits: { fileSize: 50 * 1024 * 1024 },
}));

var cors = require('cors');
const { Sockets } = require('./routes/sockets');
app.use(cors())


app.use(express.urlencoded({extended:true}))
app.use(express.json({limit:"10mb"}))

app.use('/uploads', express.static('uploads')); 

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

io.on("connection", (socket) => {
  Sockets(socket,io)
});
services(app,io);
app.get('/',(req,res)=>{
  console.log(req,res)
})

server.listen(3000,()=>{
    console.log("start")
})