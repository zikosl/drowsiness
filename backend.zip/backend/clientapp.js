const {
    login,
    signup,
    sociallogin,
    categorieswithsubs,
    getAllProduit,
    allservices
} = require('./client');

module.exports=(app)=>{
    app.post("/client/login",login)
    app.post("/client/signup",signup)
    app.post("/client/social",sociallogin)
    app.post("/client/catsub",categorieswithsubs)
    app.post("/client/produit",getAllProduit)
    app.post("/client/service",allservices)
}
