var fs = require('fs');
var db = require('../mysql');
const format = require('pg-format');
const {mailer} = require("./mailer");
const _ = require('lodash');
const fetch = require('node-fetch');
const { sendClientNotif } = require('./notification');
 
exports.token = async (req,res) =>{
	const {id,token } =req.body
	await db.query("update users set token= ? where id = ? ",[token,id]);
	res.end();
}
exports.addPicture = function (req, res) {
	var fullUrl = req.protocol + '://' + req.get('host') ;
	var base64Data = req.body.image.replace("data:"+req.body.type+";base64,", "");

	fs.writeFile("uploads/"+req.body.path+"/"+req.body.name, base64Data, 'base64',function(err){
	res.status(200).json("uploads/"+req.body.path+"/"+req.body.name)
	});
}
exports.addCategorie = async function (req, res) {
	const {title,image} = req.body
	let query = "INSERT INTO commandi.categorie (title,image,type) values (?,?,'0')";
	let rows = await db.query(query,[title,image])
	res.status(200).end();
}
exports.allCategorie = async function (req, res) {
	let query = "select * from commandi.categories ";
	let rows = await db.query(query)
	res.status(200).send(rows);
}
exports.addsubCategorie = async function (req, res) {
	const {title,image,id} = req.body
	let query = "INSERT INTO commandi.categorie (title,image,type) values (?,?,'1')";
	let rows = await db.query(query,[title,image])
	const gid = rows.insertId;
	query = "INSERT INTO commandi.subcategorie (globid,catid) values (?,?) ";
	row = await db.query(query,[gid,id]);
	res.status(200).end();
}
exports.allsubCategorie = async function (req, res) {
	const {id} = req.body
	let query = "select * from commandi.subcategories where catid = ? ";
	let rows = await db.query(query,[id])
	res.status(200).send(rows);
}
exports.allusefuleCategorie = async function (req, res) {
	let query = "select * from commandi.categorie";
	let rows = await db.query(query)
	res.status(200).send(rows);
}
exports.addService = async (req,res)=>{
	const {mail,pass,categorie} = req.body;
	let query = "INSERT INTO commandi.users (pass,mail) values (?,?) ";
	let rows = await db.query(query,[pass,mail])
	const gid = rows.insertId;
	query = "INSERT INTO commandi.services (userid) values (?) ";
	row = await db.query(query,[gid]);
	const a =[]
	categorie.forEach((v)=>a.push([rows.insertId,v]))
	query = 'INSERT INTO commandi.servicesCategories (servid,catid) values ?'
	row = await db.query(query,categorie);
	res.status(200).end();
}
exports.login = async (req,res)=> {
	const {mail,pass} = req.body
	let query = "select * from commandi.allservices where  mail = ? ";
	let rows = await db.query(query,[mail])
	console.log(rows)
	if (rows.length ==0)
	{
		res.status(401).send('user not found');
	}
	else
	{
		if(rows[0].pass == pass)
		{
			query = "select * from commandi.categorieservice where  servid = ? ";
			let value = await db.query(query,[rows[0].servid])
			rows[0].categorie = value
			console.log(rows[0],value)
			res.status(200).send(rows[0]);
		}
		else
		{
			res.status(402).send('wrong password');
		}
	}
}
exports.mailValidation =async (req,res)=>
{
	const {mail,name,id} = req.body
	let query = "select * from commandi.allservices where  mail = ? ";
	let rows = await db.query(query,[mail])
	if (rows.length ==0)
	{
		const rand = randomint();
		query = "update commandi.users set tokens = ? ,tokenid = ? where id = ?";
		await db.query(query,[rand,Date.now(),id])
		mailer({
			dest:mail,
			name:name,
			rand:rand
		})
		res.status(200).end();
	}
	else
	{
		res.status(401).send("mail already used");
		res.end();
	}
}
exports.resend = async(req,res)=>{
	const {mail,name,id} = req.body
	const rand = randomint();
	let query = "update commandi.users set tokens = ? ,tokenid =? where id = ?";
	await db.query(query,[rand,Date.now(),id])
	mailer({
		dest:mail,
		name:name,
		rand:rand
	})
	res.status(200).end();
}
exports.verifie = async (req,res)=>{
	const {token,id} = req.body
	let query = "select tokens,tokenid from commandi.users where id =? ";
	const row = await db.query(query,[id])
	if(Date.now()-row[0].tokenid <= 180*1000)
	{
		if(row[0].tokens == token)
		{
			query = "update commandi.users set tokens=null  ,tokenid =null  where id =? ";
			await db.query(query,[id])
			res.status(200).end()
		} 
		else
		{
			res.status(404).send("wrong code");
			res.end();
		}
	}
	else
	{
		res.status(402).send("you pass the request time please click resend")
		res.end();
	}
}
exports.updateService =async (req,res)=>{
	const {mail,service,map,adress,image,pass,id} = req.body
	let query = "update commandi.users set mail= ? ,pass = ?  where id =? ";
	await db.query(query,[mail,pass,id])
	query = "update commandi.services set service= ? ,adress = ? ,image =? ,maps = ?  where userid = ? ";
	await db.query(query,[service,adress,image,map,id])
	res.status(200).end();
}
exports.allmessage = async (req,res)=>{
	const {id} = req.body
	let query = "select * from commandi.chat where servid = ?";
	let row = await db.query(query,[id]);
	res.status(200).send(row);
	res.end();
}
exports.sendmessage = async (req,res)=>{
	const {id,text} = req.body
	let query = "insert into commandi.chat (servid,send,messages) values (?,?,?)";
	await db.query(query,[id,true,text]);
	res.status(200).end();
}
exports.updateprofile =async (req,res)=>{
	const {id} = req.body
	delete req.body.id
	let query = updateserviceID(id,req.body);
	var cols = Object.keys(req.body).map(function (key) {
		return req.body[key];
	});
	await db.query(query,cols)
	res.status(200).end();
}
exports.updatestatu = async (req,res)=>{
	const {online,id} = req.body
	let query = "update commandi.services set online= ?  where id =? ";
	await db.query(query,[online,id])
	res.status(200).end();
}
exports.addMenu = async (req,res) =>
{
	const {title,image,id,service} = req.body;
	let query = "insert into commandi.Menu (title,image,catid) values (?,?,?) ";
	let row = await db.query(query,[title,image,id]);
	query = "insert into commandi.serviceMenu (title,image,menuid,servid) values (?,?,?,?)";
	await db.query(query,[title,image,row.insertId,service]);
	res.status(200).end();
}
exports.AllMenu = async (req,res) =>
{
	const {id,ids} = req.body;
	var query ="SELECT * from commandi.globalmenu where servid = ?"
	let row = await db.query(query,[id]);
	var params =[],params2 =[];
	let j = ids.length;
	for(var i = 1; i <= ids.length; i++) {
		params.push('?');
	}
	for(var i = 1; i <= row.length; i++) {
		ids.push(row[i-1].menuid)
		params2.push('?');
	}
	query = 'SELECT * FROM commandi.menu WHERE catid IN (' + params.join(',') + ') and id not in (' + params2.join(',') + ')';
	let row2 = await db.query(query,ids);
	row = _.mapValues(_.groupBy(row, 'catid'),
                          clist => clist.map(prod => _.omit(prod, 'catid')));
	row2 = _.mapValues(_.groupBy(row2, 'catid'),
                          clist => clist.map(prod => _.omit(prod, 'catid')));
	res.status(200).send({
		mymenu:row,
		menu:row2
	});
	res.end();
}
exports.updateMenu = async (req,res)=>{
 const {sid,mid} = req.body;
 console.log(sid,mid)
 let query='INSERT INTO servicemenu (menuid,servid) values (?,?)';
 await db.query(query,[mid,sid]);
 res.end();
}
exports.deleteMenu = async (req,res)=>{
	const {id} = req.body; 
	await db.query('delete from servicemenu where id = ?',[id]);
	res.end();
}
function updateserviceID (id, cols) {
	// Setup static beginning of query
	var query = ['UPDATE commandi.services'];
	query.push('SET');
  
	// and assigning a number value for parameterized query
	var set = [];
	Object.keys(cols).forEach(function (key, i) {
	  set.push(key + ' = ?'); 
	});
	query.push(set.join(', '));
  
	// Add the WHERE statement to look up by id
	query.push('WHERE id = ' + id );
  
	// Return a complete query string
	return query.join(' ');
}
exports.updateMenudata =async (req,res)=>{
	const {id} = req.body
	delete req.body.id
	let query = updateID(id,req.body,"servicemenu");
	var cols = Object.keys(req.body).map(function (key) {
		return req.body[key];
	});
	await db.query(query,cols)
	console.log(cols)
	res.end();
}
exports.getProduit = async (req,res) =>{
	const {id} = req.body;
	const row = await db.query("SELECT * from produit where menuid = ?",[id])
	res.status(200).send(row);
}
exports.setSurCommand = async (req,res) =>{
	const {id,cmd} = req.body;
	await db.query("update produit set surcommand = ? where id = ?",[cmd,id])
	res.status(200).end();
}
exports.setPromo = async (req,res) =>{
	const {id,prix} = req.body;
	await db.query("update produit set promo = ? where id = ?",[prix,id])
	res.status(200).end();
}
exports.removeProduit = async (req,res) =>{
	const {id} = req.body;
	await db.query("delete from produit where id = ?",[id])
	res.status(200).end();
}
exports.addProduit = async (req,res)=>{
	const {title,image,details,prix,quantite,plugins,id} = req.body;
	await db.query("insert into produit (title,image,details,prix,quantite,plugins,menuid) values (?,?,?,?,?,?,?)",[title,image,details,prix,quantite,JSON.stringify(plugins),id])
	res.end();
}
exports.updateProduit = async (req,res)=>{
	const {id} = req.body
	delete req.body.id
	let query = updateID(id,req.body,"produit");
	var cols = Object.keys(req.body).map(function (key) {
		return req.body[key];
	});
	await db.query(query,cols)
	console.log(cols)
	res.end();
}
exports.getPannier= async (req,res)=>{
    const {sid} = req.body
    let row = await db.query("SELECT p.id,s.service,s.maps as map,s.online,p.commander,p.serviceacc,sum(c.quantite) as max,p.driveracc,p.servicesend,p.driverfinich,p.clientend,p.maps,p.dates,concat('[',group_concat(JSON_OBJECT('id',c.id,'quantite',c.quantite,'title',pr.title,'prix',pr.prix,'plugins',pr.plugins,'produitQ',pr.quantite)),']') as commands FROM pannier p join command c on (p.id=c.pannierid) JOIN produit pr on(c.produitid=pr.id) join services s on(p.serviceid=s.id) where p.serviceid = ? and p.commander = true   GROUP BY p.id",[sid])
    res.status(200).send(row)
}
exports.accepter= async (req,res,io) => {
	const {pid} = req.body;
	await db.query("update pannier set serviceacc = true where id = ?",[pid]);
	const row = (await db.query('select s.userid,p.id from clients s join pannier p on(p.clientid=s.id) where p.id = ?',[pid]))[0]
    sendClientNotif(row.userid,'Votre command N°'+row.id+' a ete accepter');
    send.users(row.userid,io);
	await driverAdd(pid);
	res.end();
}
exports.pret= async (req,res,io) => {
	const {pid} = req.body;
	await db.query("update pannier set servicesend = true where id = ?",[pid]);
	const row = (await db.query('select s.userid,p.id from clients s join pannier p on(p.clientid=s.id) where p.id = ?',[pid]))[0]
    sendClientNotif(row.userid,'Votre command N° '+row.id+"et en ligne");
	send.users(row.userid,io);
	res.end();
}
exports.refus = async (req,res,io) => {
	const {pid} = req.body;
	let row = await db.query("SELECT p.id,p.serviceid,p.driverid,p.clientid,p.maps as map,p.commander+p.serviceacc+p.driveracc+p.servicesend+p.driverfinich+p.clientend as step,p.dates,concat('[',group_concat(JSON_OBJECT('id',c.id,'quantite',c.quantite,'title',pr.title,'prix',pr.prix,'plugins',pr.plugins,'produitQ',pr.quantite)),']') as commands FROM pannier p join command c on (p.id=c.pannierid) JOIN produit pr on(c.produitid=pr.id) where p.id = ?   GROUP BY p.id",[pid])
	await db.query("INSERT into archive (dates,map,sid,cid,did,pid,commands) values (?,?,?,?,?,?,?)",[row[0].dates,row[0].map,row[0].serviceid,row[0].clientid,row[0].driverid,pid,row[0].commands])
	await db.query('delete from pannier where id = ?',[pid]);
	row = (await db.query('select s.userid,p.id from clients s join pannier p on(p.clientid=s.id) where p.id = ?',[pid]))[0]
    sendClientNotif(row.userid,'Votre command N° '+row.id+"a ete refus et deplacer dans l'historique.");
	send.users(row.userid,io);
	res.end();
}
exports.archive=  async (req,res)=>{
    const {sid} = req.body;
    const row = await db.query('SELECT * FROM archive where sid = ? ',[sid]);
    res.status(200).send(row)
    res.end();
}
async function driverAdd(pid)
{
	const a = await selectdriver(pid)
	if(a!=false)
	{
		await db.query('INSERT INTO orders (did,pid,dateadd) values ?',[a]);
		setTimeout(async ()=>{
			const ab = await db.query("SELECT driverid from pannier where id = ?",[pid]);
			if(ab[0].driverid == null)
			{
				await db.query("update orders set refus = true where pid = ?",[pid]);
				driverAdd(pid);
			}
		},40*1000)
		const ids =[]
		a.forEach(v=>{
			ids.push(v[0])
		})
		let id = await db.query('SELECT userid from drivers where id IN ?',[ids])
		id.forEach(v=>{
			sendClientNotif(id,"Vous avez recu un nouvelle command N° "+pid);
		})
	}
}
async function selectdriver(pid)
{
	let query = 'SELECT id from drivers where id not in (select driverid from pannier)';
	let res = await db.query(query);
	const OnCommand = []
	res.forEach(e=>{
		OnCommand.push(e.id);
	})
	query = "SELECT did from orders where pid = ?";
	res = await db.query(query,[pid]);
	const blocked = []
	res.forEach(e=>{
		blocked.push(e.id);
	})
	if(blocked.length+OnCommand.length ==0)
	{
		query = 'select id,maps as map from drivers';
		res = await db.query(query);
	}
	else
	{
		query = 'select id,maps as map from drivers where online=true and id not in ?';
		res = await db.query(query,[[...OnCommand,...blocked]]);
	}
	if (res.length == 0)
	{
		if(blocked.length>0)
		{
			await db.query('delete from orders where pid = ?',[pid])
			await selectdriver(pid)
		}
		else {
			return false
		}
	}
	else
	{
		let c = await db.query("select s.maps as map from services s join pannier p on (p.serviceid=s.id) where p.id = ?",[pid]);
		c = JSON.parse(c[0].map);
		const idch = []
		for(let i=0;i<res.length;i++)
		{
			const current = JSON.parse(res[i].map)
			const e = (await getDistanceOneToOne(c.latitude,c.longitude,current.latitude,current.longitude)).distance.value;
			idch.push({
				id:res[i].id,
				distance:e
			})
		}	
		idch.sort((a,b)=>a.distance-b.distance)
		let i=0;
		const idls =[]
		while(i<3 && i<idch.length)
		{
			idls.push([idch[i].id,pid,Date.now()+40000]);
			i++;
		}
		return idls;
	}
}
async function getDistanceOneToOne(lat1, lng1, lat2, lng2)
{
    const Location1Str = lat1 + "," + lng1;
    const Location2Str = lat2 + "," + lng2;
	console.log(Location1Str+" "+Location2Str)
    const GOOGLE_API_KEY = "AIzaSyCv69VO_c_zxzJQEuXgubDZ8VAF8Vy2ijA"
    let ApiURL = "https://maps.googleapis.com/maps/api/directions/json?";

    let params = `origin=${Location1Str}&destination=${Location2Str}&key=${GOOGLE_API_KEY}`; // you need to get a key
    let finalApiURL = `${ApiURL}${encodeURI(params)}`;

    let fetchResult =  await fetch(finalApiURL); // call API
    let Result =  await fetchResult.json(); // extract json
    return Result.routes[0].legs[0];
}
function updateID (id, cols,table) {
	// Setup static beginning of query
	var query = ['UPDATE '+table];
	query.push('SET');
  
	// and assigning a number value for parameterized query
	var set = [];
	Object.keys(cols).forEach(function (key, i) {
	  set.push(key + ' = ?'); 
	});
	query.push(set.join(', '));
  
	// Add the WHERE statement to look up by id
	query.push('WHERE id = ' + id );
  
	// Return a complete query string
	return query.join(' ');
}
function randomint()
{
    var a="",h,i,b;
    for (i=1;i<7;i++)
    {
        h = Math.pow(10,i)
        b = Math.floor(Math.random()*10)
        a+=b.toString();
    }
    return a;
}