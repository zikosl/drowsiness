const {
    addCategorie,
    addPicture,
    allCategorie,
    addsubCategorie,
    allsubCategorie,
    allusefuleCategorie,
    addService,
    login,
    mailValidation,
    verifie,
    resend,
    updateService,
    allmessage,
    sendmessage,
    updateprofile,
    updatestatu,
    addMenu,
    AllMenu,
    updateMenu,
    deleteMenu,
    updateMenudata,
    getProduit,
    removeProduit,
    addProduit,
    updateProduit,
    setPromo,
    setSurCommand,
    getPannier,
    accepter,
    refus,
    token,
    pret,
    archive
        } = require('./services');
module.exports=(app,io)=>{
    app.post('/token',token)
    app.post('/upload', addPicture)
    app.post("/addcategorie", addCategorie)
    app.post("/allcategorie", allCategorie)
    app.post("/addsubcategorie", addsubCategorie)
    app.post("/allsubcategorie", allsubCategorie)
    app.post("/allusefule", allusefuleCategorie)
    app.post("/addservice", addService)
    app.post("/login",login)
    app.post("/mailvalidate",mailValidation)
    app.post("/verife",verifie)
    app.post("/resend",resend)
    app.post("/updateservice",updateService)
    app.post("/messages",allmessage)
    app.post("/sendmessages",sendmessage)
    app.post("/updateprofile",updateprofile)
    app.post("/updatestatu",updatestatu)
    app.post("/addmenu",addMenu)
    app.post("/allmenu",AllMenu)
    app.post("/updatemenu",updateMenu)
    app.post('/deletemenu',deleteMenu)
    app.post('/updatemenudata',updateMenudata)
    app.post('/allproduit',getProduit)
    app.post('/removeproduit',removeProduit)
    app.post('/addproduit',addProduit)
    app.post('/updateproduit',updateProduit)
    app.post('/setpromo',setPromo)
    app.post('/surcommand',setSurCommand)
    app.post('/pannier',getPannier)
    app.post('/accepter',(req,res)=>accepter(req,res,io))
    app.post('/pret',(req,res)=>pret(req,res,io))
    app.post('/refus',(req,res)=>refus(req,res,io))
    app.post('/archive',archive)
}